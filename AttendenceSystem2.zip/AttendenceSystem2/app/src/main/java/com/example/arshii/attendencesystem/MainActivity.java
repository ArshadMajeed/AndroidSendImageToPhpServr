package com.example.arshii.attendencesystem;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.test.mock.MockPackageManager;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Button mCapturePhoto,mBrowseImage;
    private String encoded_string, image_name;
    private Bitmap bitmap;
    private File file;
    private Uri image_uri,browse_uri;
    private EditText ipAdress;
    private String ip;
    private int PICK_IMAGE_REQUEST = 10;
    private int PERMISSION_REQUEST_CODE = 5;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ipAdress = (EditText) findViewById(R.id.serverIp);
        mCapturePhoto = (Button) findViewById(R.id.captureImage);
        mBrowseImage = (Button) findViewById(R.id.browseImageBtn);
        image_name = "arshiii.jpg";
        progressDialog=new ProgressDialog(this);
       //checkForPermission();
        mBrowseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               chooseImage();
            }
        });

        mCapturePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!hasRuntimePermission(getApplicationContext(), Manifest.permission.CAMERA)) {
                    requestRuntimePermission(MainActivity.this, Manifest.permission.CAMERA, PERMISSION_REQUEST_CODE);
                } else {
                   // Toast.makeText(MainActivity.this, "Manifest.permission.CAMERA permission already has been granted", Toast.LENGTH_LONG).show();
                    openCamera();
                }


            }
        });
    }

   public void openCamera(){
        if (!TextUtils.isEmpty(ipAdress.getText())){
            ip = ipAdress.getText().toString();
            capturePhoto();
        }
        else{
            Toast.makeText(MainActivity.this, "Enter ip adress", Toast.LENGTH_SHORT).show();
        }
    }
    private void requestRuntimePermission(Activity activity, String runtimePermission, int requestCode)
    {
        ActivityCompat.requestPermissions(activity, new String[]{runtimePermission}, requestCode);
    }

    //This method is used to check whether current app has required runtime permission.
    private boolean hasRuntimePermission(Context context, String runtimePermission)
    {
        boolean ret = false;

        // Get current android os version.
        int currentAndroidVersion = Build.VERSION.SDK_INT;

        // Build.VERSION_CODES.M's value is 23.
        if(currentAndroidVersion > Build.VERSION_CODES.M)
        {
            // Only android version 23+ need to check runtime permission.
            if(ContextCompat.checkSelfPermission(context, runtimePermission) == PackageManager.PERMISSION_GRANTED)
            {
                ret = true;
            }
        }else
        {
            ret = true;
        }
        return ret;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==PERMISSION_REQUEST_CODE)
        {
            if(grantResults.length > 0)
            {
                int grantResult = grantResults[0];
                if(grantResult == PackageManager.PERMISSION_GRANTED)
                {
                    // If user grant the permission then open choose image popup dialog.
                    openCamera();
                }else
                {
                    Toast.makeText(getApplicationContext(), "You denied read external storage permission.", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
    ////////////////


    private void chooseImage() {
      Intent intent = new Intent();
// Show only images, no videos or anything else
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
       // getFileUri();
       // intent.putExtra(MediaStore.EXTRA_OUTPUT,image_uri);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
        //





    }


    private void checkForPermission() {

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
                 ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.READ_CONTACTS},
                        2);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.

        }
    }



    private void capturePhoto() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA}, 1);
        }
        else{
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            getFileUri();
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,image_uri);
            startActivityForResult(cameraIntent,1);
        }



    }

    private void getFileUri() {


        file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+
                File.separator + image_name
        );
        image_uri = Uri.fromFile(file);
    //    Toast.makeText(this, image_uri.toString(), Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == 1 && resultCode == RESULT_OK){
            new encodeImage().execute();
        }
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK){
          //  Toast.makeText(this, "Hellow", Toast.LENGTH_SHORT).show();
            image_uri = data.getData();
            new encodeImage().execute();

        }
    }


    private class encodeImage extends AsyncTask<Void,Void,Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setTitle("Sending");
            progressDialog.setMessage("Please Wait..........");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
               // bitmap = BitmapFactory.decodeFile(image_uri.getPath());
                bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(image_uri));
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG,75,stream);
                byte[] byteArray = stream.toByteArray();
                encoded_string = Base64.encodeToString(byteArray,0);
                Log.i("ec",encoded_string);


            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            image_uri = null;
            makeConnectionRequest();
        }
        private void makeConnectionRequest() {
            RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
            StringRequest request = new StringRequest(Request.Method.POST, "http://"+ip+"/Android/connection.php",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Toast.makeText(MainActivity.this, "Successfull uploaded", Toast.LENGTH_SHORT).show();
                            encoded_string = null;
                            progressDialog.dismiss();

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                   // Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                    encoded_string = null;
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String,String> map = new HashMap<>();
                    map.put("encoded_string",encoded_string);
                    map.put("image_name",image_name);
                    return map;
                }
            };
            requestQueue.add(request);
        }
    }


}
